package com.example.calci_unitconverter;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link RomtoDec#newInstance} factory method to
 * create an instance of this fragment.
 */
public class RomtoDec extends Fragment {

    EditText dec_input;
    EditText rom_input;
    TextView dec_output;
    TextView rom_output;
    Button b_converttoRoman;
    Button b_converttodecimal;
    String string1, string2, rom_num;
    double dec_num;


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public RomtoDec() {
    }

    // TODO: Rename and change types and number of parameters
    public static RomtoDec newInstance(String param1, String param2) {
        RomtoDec fragment = new RomtoDec();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

            b_converttoRoman = (Button) getView().findViewById(R.id.currency_convert);
            b_converttodecimal = (Button)getView().findViewById(R.id.currency_convert2);
            dec_input = (EditText) getView().findViewById(R.id.decimal_input);
            rom_input = (EditText) getView().findViewById(R.id.roman_input);
            dec_output = (TextView) getView().findViewById(R.id.Romanswer);
            rom_output = (TextView) getView().findViewById(R.id.decanswer);

            b_converttodecimal.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    NumberConverter NumCon = new NumberConverter();
                    String userinputstring = rom_input.getText().toString();
                    int todecimalnumber;
                    todecimalnumber = NumCon.toNumber(userinputstring);
                    dec_output.setText(todecimalnumber);
                }
            });

            b_converttoRoman.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    NumberConverter NumCon = new NumberConverter();
                    int userinputnumber= Integer.parseInt(dec_input.getText().toString()); // Input given by user

                    String toromannumber; // data which goes back to user
                    toromannumber = NumCon.toRoman(userinputnumber);
                    rom_output.setText(toromannumber);
                }
            });
        }
    }

//    public boolean GetRomNumber(){
//        rom_input= (EditText) getView().findViewById(R.id.roman_input);
//        rom_output = (TextView) getView().findViewById(R.id.Romanswer);
//        string1 = rom_input.getText().toString();
//        if(string1.equals(null) || string1.equals("")){
//            String out = (" Please Enter Roman Input");
//            rom_output.setText(out);
//            return false;
//        }else{
//            rom_input
//        }
//        return true;
//    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_romto_dec, container, false);
    }
}