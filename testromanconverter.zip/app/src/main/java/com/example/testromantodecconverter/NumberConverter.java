package com.example.testromantodecconverter;

public class NumberConverter {
    public String toRoman (int numberinput){

        String returnstringvalue=" ";

        if(numberinput<0 || numberinput>100000){
            return "Out of given range";
        }
        while(numberinput >=1000){
            returnstringvalue += "M";
            numberinput -=1000;
        }
        while(numberinput >=900){
            returnstringvalue += "CM";
            numberinput -=900;
        }
        while(numberinput >=500){
            returnstringvalue += "D";
            numberinput -=500;
        }
        while(numberinput >=400){
            returnstringvalue += "CD";
            numberinput -=400;
        }
        while(numberinput >=100){
            returnstringvalue += "C";
            numberinput -=100;
        }
        while(numberinput >=90){
            returnstringvalue += "XC";
            numberinput -=90;
        }
        while(numberinput >=50){
            returnstringvalue += "L";
            numberinput -=50;
        }
        while(numberinput >=40){
            returnstringvalue += "XL";
            numberinput -=40;
        }
        while(numberinput >=10){
            returnstringvalue += "X";
            numberinput -=10;
        }
        while(numberinput >=9){
            returnstringvalue += "IX";
            numberinput -=9;
        }
        while(numberinput >=5){
            returnstringvalue += "V";
            numberinput -=5;
        }
        while(numberinput >=4){
            returnstringvalue += "IV";
            numberinput -=4;
        }
        while(numberinput >=1){
            returnstringvalue += "I";
            numberinput -=1;
        }
        return returnstringvalue;
    }

    public int toNumber (String romaninput){

        int decimal=0;
        int lastnumber=0;
        String romannumeral = romaninput.toUpperCase();
        for(int i=romannumeral.length()-1; i>=0; i--){
            char converttodecimal = romannumeral.charAt(i);
            switch (converttodecimal){
                case 'M':

                    decimal= processDecimal(1000,lastnumber,decimal);
                    lastnumber=1000;
                    break;

                case 'D':
                    decimal= processDecimal(500,lastnumber,decimal);
                    lastnumber=500;
                    break;
                case 'C':
                    decimal= processDecimal(100,lastnumber,decimal);
                    lastnumber=100;
                    break;
                case 'L':
                    decimal= processDecimal(50,lastnumber,decimal);
                    lastnumber=50;
                    break;
                case 'X':
                    decimal= processDecimal(10,lastnumber,decimal);
                    lastnumber=10;
                    break;
                case 'V':
                    decimal= processDecimal(5,lastnumber,decimal);
                    lastnumber=5;
                    break;
                case 'I':
                    decimal= processDecimal(1,lastnumber,decimal);
                    lastnumber=1;
                    break;
            }
        }
        return decimal;
    }

    public static int processDecimal(int decimal,int lastnumber,int lastdecimal){
        if(lastnumber>decimal){
            return lastdecimal-decimal;
        }else{
            return lastdecimal+decimal;
        }
//        if (number == String.isEmpty()) return 0;
//        if (number.startsWith("M")) return 1000 + toNumber(number.Remove(0, 1));
//        if (number.startsWith("CM")) return 900 + toNumber(number.Remove(0, 2));
//        if (number.startsWith("D")) return 500 + toNumber(number.Remove(0, 1));
//        if (number.startsWith("CD")) return 400 + toNumber(number.Remove(0, 2));
//        if (number.startsWith("C")) return 100 + toNumber(number.Remove(0, 1));
//        if (number.startsWith("XC")) return 90 + toNumber(number.Remove(0, 2));
//        if (number.startsWith("L")) return 50 + toNumber(number.Remove(0, 1));
//        if (number.startsWith("XL")) return 40 + toNumber(number.Remove(0, 2));
//        if (number.startsWith("X")) return 10 + toNumber(number.Remove(0, 1));
//        if (number.startsWith("IX")) return 9 + toNumber(number.Remove(0, 2));
//        if (number.startsWith("V")) return 5 + toNumber(number.Remove(0, 1));
//        if (number.startsWith("IV")) return 4 + toNumber(number.Remove(0, 2));
//        if (number.startsWith("I")) return 1 + toNumber(number.Remove(0, 1));
//        throw new ArgumentOutOfRangeException("something bad happened");

    }
}
