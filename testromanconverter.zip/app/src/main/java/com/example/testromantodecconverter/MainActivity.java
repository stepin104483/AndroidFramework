package com.example.testromantodecconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText dec_input;
    EditText rom_input;
    TextView dec_output;
    TextView rom_output;
    Button b_converttoRoman;
    Button b_converttodecimal;
    String string1, string2, rom_num;
    double dec_num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b_converttoRoman = (Button) findViewById(R.id.currency_convert);
        b_converttodecimal = (Button)findViewById(R.id.currency_convert2);
        dec_input = (EditText) findViewById(R.id.decimal_input);
        rom_input = (EditText) findViewById(R.id.roman_input);
        dec_output = (TextView) findViewById(R.id.Romanswer);
        rom_output = (TextView) findViewById(R.id.decanswer);

        b_converttodecimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NumberConverter NumCon = new NumberConverter();
                String userinputstring = rom_input.getText().toString();
                int todecimalnumber;
                todecimalnumber = NumCon.toNumber(userinputstring);
                dec_output.setText(todecimalnumber);
            }
        });

        b_converttoRoman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NumberConverter NumCon = new NumberConverter();
                int userinputnumber= Integer.parseInt(dec_input.getText().toString()); // Input given by user

                String toromannumber; // data which goes back to user
                toromannumber = NumCon.toRoman(userinputnumber);
                rom_output.setText(toromannumber);
            }
    });
}
}