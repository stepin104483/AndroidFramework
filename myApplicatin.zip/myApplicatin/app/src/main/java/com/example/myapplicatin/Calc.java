package com.example.myapplicatin;
public class Calc {
    public static int add(int x, int y)
    {
        return (x+y);
    }
}
