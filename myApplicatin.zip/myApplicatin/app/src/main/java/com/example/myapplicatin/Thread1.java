package com.example.myapplicatin;

public class Thread1 extends Thread{
    public void run()
    {
        Table.print(1000);
    }
}
